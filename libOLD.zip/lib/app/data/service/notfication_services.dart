import "dart:developer" as lg;
import 'dart:math';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:rudra/app/routes/app_routes.dart' show AppRoutes;
import 'package:rudra/bottom_navigation/bottom_navigation_controller.dart'
    show BottomNavigationController;

class NotificationServices {
  String? callId;
  FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;

  final FlutterLocalNotificationsPlugin flutterlocalnotificationplugin =
      FlutterLocalNotificationsPlugin();

  // static final onNotifications = BehaviorSubject<String?>();

  void requestNotificationPermission() async {
    try {
      FirebaseMessaging messaging = FirebaseMessaging.instance;
      NotificationSettings settings = await messaging.requestPermission(
        alert: true,
        announcement: true,
        badge: true,
        sound: true,
      );

      if (settings.authorizationStatus == AuthorizationStatus.authorized) {
        print('User granted permission');
      } else if (settings.authorizationStatus ==
          AuthorizationStatus.provisional) {
        print('User granted provisional permission');
      } else {
        print('User declined or has not accepted permission');
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void initLocalNotifications(
    BuildContext context,
    RemoteMessage message,
  ) async {
    try {
      var androidInitialization = const AndroidInitializationSettings(
        '@mipmap/ic_launcher',
      );
      var iosInitialization = const DarwinInitializationSettings();
      var initializationSettings = InitializationSettings(
        android: androidInitialization,
        iOS: iosInitialization,
      );

      // Initialize only with click action handling
      await flutterlocalnotificationplugin.initialize(
        initializationSettings,
        onDidReceiveNotificationResponse: (response) {
          // Check the notification response and handle navigation
          if (response.payload != null) {
            handleRemoteMessage(context, message);
          }
        },
      );
    } catch (e) {
      print(e.toString());
    }
  }

  void firebaseInit(BuildContext context) {
    try {
      FirebaseMessaging.onMessage.listen((message) {
        if (message.notification != null || message.data.isNotEmpty) {
          initLocalNotifications(context, message);
          showNotification(message);
        }
      });
    } catch (e) {
      print(e.toString());
    }
  }

  Future<void> showNotification(RemoteMessage message) async {
    try {
      AndroidNotificationChannel channel = AndroidNotificationChannel(
        Random.secure().nextInt(100000).toString(),
        'text_channel',
        importance: Importance.high,
      );

      AndroidNotificationDetails androidNotificationDetails =
          AndroidNotificationDetails(
        channel.id.toString(),
        channel.name.toString(),
        channelDescription: 'Your channel Description',
        importance: Importance.high,
        priority: Priority.high,
        playSound: true,
        styleInformation: const BigTextStyleInformation(''),
        //  sound: RawResourceAndroidNotificationSound('res_custom_message'),
        ticker: 'ticker',
      );

      DarwinNotificationDetails darwinNotificationDetails =
          const DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      );

      NotificationDetails notificationDetails = NotificationDetails(
        android: androidNotificationDetails,
        iOS: darwinNotificationDetails,
      );

      // Fetch title and body, prioritizing `message.notification` for compatibility
      String? title = message.notification?.title ?? message.data['title'];
      String? body = message.notification?.body ?? message.data['body'];

      // Display the notification only if title or body is not null
      if (title != null || body != null) {
        flutterlocalnotificationplugin.show(
          1,
          title ?? "No Title", // Default to "No Title" if null
          body ?? "No Body", // Default to "No Body" if null
          notificationDetails,
        );
      }
    } catch (e) {
      print(e.toString());
    }
  }

  Future<String> getDevicetoken() async {
    String? token = await firebaseMessaging.getToken();
    return token!;
  }

  void isTokenRefresh() {
    try {
      firebaseMessaging.onTokenRefresh.listen((event) {
        event.toString();
      });
    } catch (e) {
      print(e.toString());
    }
  }

  Future<void> setInteractMessage(BuildContext context) async {
    //when app is termitted
    try {
      RemoteMessage? initialmessage =
          await FirebaseMessaging.instance.getInitialMessage();
      if (initialmessage != null) {
        handleRemoteMessage(context, initialmessage);
      }
      //when app is in background
      FirebaseMessaging.onMessageOpenedApp.listen((event) {
        handleRemoteMessage(context, event);
      });
    } catch (e) {
      print(e.toString());
    }
  }

  void handleRemoteMessage(BuildContext context, RemoteMessage message) async {
    try {
      BottomNavigationController controller1 = Get.put(
        BottomNavigationController(),
      );
      lg.log("Controller1 initialized: ${controller1.selectedIndex}");

      String landingPage =
          message.data['landing_page']?.toString().toLowerCase() ?? 'default';
      String batchId = message.data['batch_id']?.toString() ?? '';
      String body = message.data['body']?.toString() ?? '';
      lg.log(landingPage);
      RegExp regex = RegExp(r"result for '([^']*)'");
      Match? match = regex.firstMatch(body);
      String examName = match?.group(1) ?? '';

      lg.log("${message.data}");
      lg.log("Current route: ${Get.currentRoute}");
      lg.log("Context available: ${context != null}");
      lg.log("Expected route: ${AppRoutes.home}");

      // Navigate to home if not already there
      if (Get.currentRoute != AppRoutes.home) {
        lg.log("Navigating to HomeContainer1Screen");
        try {
          Get.offAllNamed(AppRoutes.home);
          lg.log("Navigation to HomeContainer1Screen completed");
        } catch (navError) {
          lg.log("Navigation error: $navError");
          return;
        }
      } else {
        lg.log("Already on HomeContainer1Screen");
      }

      lg.log("Processing landing page: $landingPage");
      switch (landingPage) {
        case "exam_list_page":
          lg.log("Navigating to ExamListScreen");
          Get.toNamed(AppRoutes.home);
          lg.log("Navigation to ExamListScreen completed");
          break;
        case "announcement":
          lg.log("Navigating to AnnouncementForStudent");
          Get.toNamed(AppRoutes.home);
          lg.log("Navigation to AnnouncementForStudent completed");
          break;
        case "test_result_page":
          lg.log("Navigating to ResultScreen");
          Get.toNamed(AppRoutes.home);
          lg.log("Navigation to ResultScreen completed");
          break;
        default:
          lg.log("DEFAULT NAVIGATION====> home");
          controller1.goToHome();
          break;
      }
    } catch (e) {
      lg.log("Error in handleRemoteMessage: $e");
    }
  }
}
